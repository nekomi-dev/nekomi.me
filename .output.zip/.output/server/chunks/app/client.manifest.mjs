const client_manifest = {
  "Button.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Button.1c14fd80.css",
    "src": "Button.css"
  },
  "_Button.d2a7da62.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "Button.1c14fd80.css"
    ],
    "file": "Button.d2a7da62.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "Button.1c14fd80.css": {
    "file": "Button.1c14fd80.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Icons.3221a735.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Icons.3221a735.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_nuxt-link.95a923df.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "nuxt-link.95a923df.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.1924bc7e.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.7fff78dc.js",
    "imports": [
      "_nuxt-link.95a923df.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_Button.d2a7da62.js",
      "_Icons.3221a735.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.1924bc7e.css": {
    "file": "default.1924bc7e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-404.7fc72018.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-404.a008db6d.js",
    "imports": [
      "_nuxt-link.95a923df.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue"
  },
  "error-404.7fc72018.css": {
    "file": "error-404.7fc72018.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "error-500.c5df6088.css",
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.css"
  },
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "error-500.66e75968.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
  },
  "error-500.c5df6088.css": {
    "file": "error-500.c5df6088.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.b23080bc.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.b23080bc.css"
    ],
    "dynamicImports": [
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "layouts/default.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue",
      "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue"
    ],
    "file": "entry.f8cb6dc9.js",
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.b23080bc.css": {
    "file": "entry.b23080bc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/primevue/multiselect/multiselect.esm.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "multiselect.esm.fdee57c8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/primevue/multiselect/multiselect.esm.js"
  },
  "pages/auth.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "auth.71dad0f9.css",
    "src": "pages/auth.css"
  },
  "pages/auth.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "auth.97414098.js",
    "imports": [
      "_nuxt-link.95a923df.js",
      "_Button.d2a7da62.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/auth.vue"
  },
  "auth.71dad0f9.css": {
    "file": "auth.71dad0f9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.8f17c622.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.fc2fed03.js",
    "imports": [
      "_Icons.3221a735.js",
      "_Button.d2a7da62.js",
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/primevue/multiselect/multiselect.esm.js",
      "_nuxt-link.95a923df.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.8f17c622.css": {
    "file": "index.8f17c622.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/reg.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "reg.6a21297e.css",
    "src": "pages/reg.css"
  },
  "pages/reg.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "reg.71268be0.js",
    "imports": [
      "_nuxt-link.95a923df.js",
      "_Button.d2a7da62.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/reg.vue"
  },
  "reg.6a21297e.css": {
    "file": "reg.6a21297e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/watch/[code].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_code_.7d4870a6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/watch/[code].vue"
  },
  "pages/watch/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.cefd415a.css",
    "src": "pages/watch/index.css"
  },
  "pages/watch/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9c00ee72.js",
    "imports": [
      "_Icons.3221a735.js",
      "_Button.d2a7da62.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/watch/index.vue"
  },
  "index.cefd415a.css": {
    "file": "index.cefd415a.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.693050bc.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
