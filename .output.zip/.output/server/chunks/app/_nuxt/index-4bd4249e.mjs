import { _ as __nuxt_component_2$1 } from './Icons-1f48bf3e.mjs';
import { u as useDevice, _ as __nuxt_component_1 } from './Button-00fd5b58.mjs';
import { useSSRContext, ref, resolveComponent, unref, withCtx, createVNode, createTextVNode, isRef, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderClass, ssrRenderList, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import { useEditor, EditorContent } from '@tiptap/vue-3';
import Placeholder from '@tiptap/extension-placeholder';
import StarterKit from '@tiptap/starter-kit';
import { Mark } from '@tiptap/core';
import { _ as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main$1 = {
  __name: "Editor",
  __ssrInlineRender: true,
  props: {
    placeholder: {
      default: "",
      type: String
    }
  },
  setup(__props) {
    const props = __props;
    const Bold = Mark.create({
      name: "bold",
      addAttributes() {
        return {
          class: {
            default: "bold-comm"
          }
        };
      },
      parseHTML() {
        return [
          {
            tag: "strong",
            class: "bold-comm"
          }
        ];
      },
      renderHTML({ HTMLAttributes }) {
        return ["strong", HTMLAttributes, 0];
      }
    });
    const Italic = Mark.create({
      name: "italic",
      addAttributes() {
        return {
          class: {
            default: "italic-comm"
          }
        };
      },
      parseHTML() {
        return [
          {
            tag: "em",
            class: "italic-comm"
          }
        ];
      },
      renderHTML({ HTMLAttributes }) {
        return ["em", HTMLAttributes, 0];
      }
    });
    const Strike = Mark.create({
      name: "strike",
      addAttributes() {
        return {
          class: {
            default: "strike-comm"
          }
        };
      },
      parseHTML() {
        return [
          {
            tag: "s",
            class: "strike-comm"
          }
        ];
      },
      renderHTML({ HTMLAttributes }) {
        return ["s", HTMLAttributes, 0];
      }
    });
    const Spoiler = Mark.create({
      name: "spoiler",
      addAttributes() {
        return {
          class: {
            default: "spoiler-comm"
          }
        };
      },
      parseHTML() {
        return [
          {
            tag: "span",
            class: "spoiler-comm"
          }
        ];
      },
      renderHTML({ HTMLAttributes }) {
        return ["span", HTMLAttributes, 0];
      },
      // Добавляем команды для переключения спойлера
      addCommands() {
        return {
          toggleSpoiler: () => ({ commands }) => {
            return commands.toggleMark(this.name);
          }
        };
      },
      addKeyboardShortcuts() {
        return {
          // ↓ your new keyboard shortcut
          "Mod-shift-r": () => this.editor.commands.toggleMark(this.name)
        };
      }
    });
    const editor = useEditor({
      content: "",
      extensions: [
        StarterKit,
        Spoiler,
        Bold,
        Italic,
        Strike,
        Placeholder.configure({
          placeholder: props.placeholder
        })
      ],
      editorProps: {
        attributes: {
          class: "editor-content"
        }
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UIButton = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "editor-wrapper" }, _attrs))} data-v-74603f71>`);
      _push(ssrRenderComponent(unref(EditorContent), { editor: unref(editor) }, null, _parent));
      _push(`<div class="editor-toolbar" data-v-74603f71>`);
      if (unref(editor)) {
        _push(ssrRenderComponent(_component_UIButton, {
          onClick: ($event) => unref(editor).chain().focus().toggleBold().run(),
          class: { "is-active": unref(editor).isActive("bold") },
          typeStyle: "['nav', 'icon']"
        }, {
          tooltip: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u2318B`);
            } else {
              return [
                createTextVNode("\u2318B")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<strong data-v-74603f71${_scopeId}>B</strong>`);
            } else {
              return [
                createVNode("strong", null, "B")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(editor)) {
        _push(ssrRenderComponent(_component_UIButton, {
          onClick: ($event) => unref(editor).chain().focus().toggleItalic().run(),
          class: { "is-active": unref(editor).isActive("italic") },
          typeStyle: "['nav', 'icon']"
        }, {
          tooltip: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u2318i`);
            } else {
              return [
                createTextVNode("\u2318i")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<em data-v-74603f71${_scopeId}>i</em>`);
            } else {
              return [
                createVNode("em", null, "i")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(editor)) {
        _push(ssrRenderComponent(_component_UIButton, {
          onClick: ($event) => unref(editor).chain().focus().toggleStrike().run(),
          class: { "is-active": unref(editor).isActive("strike") },
          typeStyle: "['nav', 'icon']"
        }, {
          tooltip: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u2318\u21E7S`);
            } else {
              return [
                createTextVNode("\u2318\u21E7S")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<s data-v-74603f71${_scopeId}>S</s>`);
            } else {
              return [
                createVNode("s", null, "S")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(editor)) {
        _push(ssrRenderComponent(_component_UIButton, {
          onClick: ($event) => unref(editor).chain().focus().toggleSpoiler().run(),
          class: { "is-active": unref(editor).isActive("spoiler") },
          typeStyle: "['nav', 'icon']"
        }, {
          tooltip: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u2318\u21E7R`);
            } else {
              return [
                createTextVNode("\u2318\u21E7R")
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` {s} `);
            } else {
              return [
                createTextVNode(" {s} ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Editor.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-74603f71"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { isMobile } = useDevice();
    const episodes = [
      "1",
      "2",
      "3",
      "4",
      "5",
      "6",
      "7",
      "8",
      "9",
      "10",
      "11",
      "12"
    ];
    const selects = ref({
      currentEpisode: null,
      currentDub: null,
      currentPlayer: null
    });
    const isChat = ref(true);
    const toggleChat = () => {
      if (isChat.value && !isMobile) {
        setTimeout(() => {
          window.scrollTo({
            top: 120,
            behavior: "smooth"
          });
        }, 270);
      }
      isChat.value = !isChat.value;
    };
    const comment = ref("");
    const loadPlayer = () => {
      new Playerjs({
        id: "player",
        file: "/anime_video.mp4"
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Script = resolveComponent("Script");
      const _component_IconIcons = __nuxt_component_2$1;
      const _component_UIButton = __nuxt_component_1;
      const _component_UIEditor = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(_attrs)} data-v-6fd045fd>`);
      _push(ssrRenderComponent(_component_Script, {
        onLoad: loadPlayer,
        src: "/lib/player.js",
        type: "text/javascript"
      }, null, _parent));
      _push(`<div class="container" data-v-6fd045fd><div class="player" data-v-6fd045fd><div class="player__container" data-v-6fd045fd><div class="${ssrRenderClass([{ closed: !unref(isChat) }, "player__video"])}" data-v-6fd045fd><div class="player__videoPlayer" data-v-6fd045fd><div id="player" data-v-6fd045fd></div><div class="player__episodes" data-v-6fd045fd><!--[-->`);
      ssrRenderList(episodes, (item) => {
        _push(`<div class="${ssrRenderClass([{
          "player__episodes-item--active": unref(selects).currentItem === item
        }, "player__episodes-item"])}" data-v-6fd045fd>${ssrInterpolate(item + " \u0441\u0435\u0440\u0438\u044F")}</div>`);
      });
      _push(`<!--]--></div></div><div class="player__info" data-v-6fd045fd><div class="player__info-text" data-v-6fd045fd><h1 class="player__info-title" data-v-6fd045fd>\u0420\u0435\u0438\u043D\u043A\u0430\u0440\u043D\u0430\u0446\u0438\u044F \u0411\u0435\u0437\u0440\u0430\u0431\u043E\u0442\u043D\u043E\u0433\u043E</h1><p class="player__info-tags" data-v-6fd045fd><span data-v-6fd045fd>12 \u0441\u0435\u0440\u0438\u0439</span>`);
      _push(ssrRenderComponent(_component_IconIcons, {
        dot: "",
        size: 3,
        color: "var(--white-alpha50)"
      }, null, _parent));
      _push(`<span data-v-6fd045fd>\u0420\u0435\u043A\u043B\u0430\u043C\u0430</span>`);
      _push(ssrRenderComponent(_component_IconIcons, {
        dot: "",
        size: 3,
        color: "var(--white-alpha50)"
      }, null, _parent));
      _push(`<span data-v-6fd045fd>nekomi.player</span></p></div><div class="player__info-tools" data-v-6fd045fd>`);
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'blueed', 'icon']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              mic: "",
              size: 16,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
            _push2(` \u041E\u0437\u0432\u0443\u0447\u043A\u0430 `);
          } else {
            return [
              createVNode(_component_IconIcons, {
                mic: "",
                size: 16,
                color: "var(--white)"
              }),
              createTextVNode(" \u041E\u0437\u0432\u0443\u0447\u043A\u0430 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              favorite: "",
              filled: "",
              size: 16,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_IconIcons, {
                favorite: "",
                filled: "",
                size: 16,
                color: "var(--white)"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, {
        typeStyle: "['transparent', 'icon']",
        onClick: ($event) => toggleChat()
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              chat: "",
              size: 16,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_IconIcons, {
                chat: "",
                size: 16,
                color: "var(--white)"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><div class="player__comments" style="${ssrRenderStyle(unref(isChat) ? null : { display: "none" })}" data-v-6fd045fd><h2 class="player__comments-title" data-v-6fd045fd>\u041A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0438</h2>`);
      _push(ssrRenderComponent(_component_UIEditor, {
        modelValue: unref(comment),
        "onUpdate:modelValue": ($event) => isRef(comment) ? comment.value = $event : null,
        placeholder: "\u041E\u0441\u0442\u0430\u0432\u0438\u0442\u044C \u043A\u043E\u043C\u043C\u0435\u043D\u0442\u0430\u0440\u0438\u0439..."
      }, null, _parent));
      _push(`<div class="player__comments-list" data-v-6fd045fd></div></div></div></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/watch/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-6fd045fd"]]);

export { index as default };
//# sourceMappingURL=index-4bd4249e.mjs.map
