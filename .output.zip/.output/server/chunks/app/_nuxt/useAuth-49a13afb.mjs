import { toRef, isRef } from 'vue';
import { n as navigateTo, b as useNuxtApp } from '../server.mjs';

const useStateKeyPrefix = "$s";
function useState(...args) {
  const autoKey = typeof args[args.length - 1] === "string" ? args.pop() : void 0;
  if (typeof args[0] !== "string") {
    args.unshift(autoKey);
  }
  const [_key, init] = args;
  if (!_key || typeof _key !== "string") {
    throw new TypeError("[nuxt] [useState] key must be a string: " + _key);
  }
  if (init !== void 0 && typeof init !== "function") {
    throw new Error("[nuxt] [useState] init must be a function: " + init);
  }
  const key = useStateKeyPrefix + _key;
  const nuxt = useNuxtApp();
  const state = toRef(nuxt.payload.state, key);
  if (state.value === void 0 && init) {
    const initialValue = init();
    if (isRef(initialValue)) {
      nuxt.payload.state[key] = initialValue;
      return initialValue;
    }
    state.value = initialValue;
  }
  return state;
}
const useAuth = () => {
  const isAuth = useState("auth", () => false);
  const user = useState("user", () => null);
  const updateAuth = () => {
    isAuth.value = localStorage.getItem("isAuth") ? true : false;
    const userData = localStorage.getItem("user");
    user.value = userData ? JSON.parse(userData) : null;
  };
  const logout = () => {
    localStorage.removeItem("isAuth");
    localStorage.removeItem("user");
    isAuth.value = false;
    user.value = null;
    navigateTo("/");
  };
  return {
    isAuth,
    user,
    updateAuth,
    logout
  };
};

export { useAuth as u };
//# sourceMappingURL=useAuth-49a13afb.mjs.map
