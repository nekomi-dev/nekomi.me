import { _ as __nuxt_component_0 } from './nuxt-link-99c863e4.mjs';
import { _ as __nuxt_component_1 } from './Button-00fd5b58.mjs';
import { ref, mergeProps, unref, withCtx, createTextVNode, useSSRContext } from 'vue';
import { _ as _export_sfc, a as useRouter, n as navigateTo } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { u as useAuth } from './useAuth-49a13afb.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const _sfc_main = {
  __name: "reg",
  __ssrInlineRender: true,
  setup(__props) {
    const email = ref("");
    const password = ref("");
    const { updateAuth } = useAuth();
    useRouter();
    const handleLogin = async () => {
      try {
        if (!email.value || !password.value) {
          return alert("\u0417\u0430\u043F\u043E\u043B\u043D\u0438\u0442\u0435 \u0432\u0441\u0435 \u043F\u043E\u043B\u044F");
        }
        if (email.value === "hikeru1@icloud.com" && password.value === "admin") {
          localStorage.setItem("isAuth", "true");
          localStorage.setItem(
            "user",
            JSON.stringify({
              email: email.value,
              role: "admin",
              name: "\u041D\u0438\u043A\u0438\u0442\u0430"
            })
          );
          updateAuth();
          await navigateTo("/");
        } else {
          alert("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438 (\u041D\u0435\u043F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u044B\u0439 email \u0438\u043B\u0438 \u043F\u0430\u0440\u043E\u043B\u044C)");
        }
      } catch (error) {
        alert("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0440\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u0438");
        console.error(error);
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0;
      const _component_UIButton = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "auth-container" }, _attrs))} data-v-a4e31250><div class="auth-form" data-v-a4e31250><h2 data-v-a4e31250>\u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044F</h2><div class="form-group" data-v-a4e31250><input${ssrRenderAttr("value", unref(email))} type="email" placeholder="Email" class="input" data-v-a4e31250></div><div class="form-group" data-v-a4e31250><input${ssrRenderAttr("value", unref(password))} type="password" placeholder="\u041F\u0430\u0440\u043E\u043B\u044C" class="input" data-v-a4e31250></div>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        class: "auth-form__link",
        to: "/auth"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0415\u0441\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442? \u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0443\u0439\u0442\u0435\u0441\u044C`);
          } else {
            return [
              createTextVNode("\u0415\u0441\u0442\u044C \u0430\u043A\u043A\u0430\u0443\u043D\u0442? \u0410\u0432\u0442\u043E\u0440\u0438\u0437\u0443\u0439\u0442\u0435\u0441\u044C")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, {
        typeStyle: ["blue"],
        onClick: handleLogin
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` \u0412\u043E\u0439\u0442\u0438 `);
          } else {
            return [
              createTextVNode(" \u0412\u043E\u0439\u0442\u0438 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/reg.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const reg = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-a4e31250"]]);

export { reg as default };
//# sourceMappingURL=reg-9c773739.mjs.map
