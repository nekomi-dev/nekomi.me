import { b as useNuxtApp, _ as _export_sfc } from '../server.mjs';
import { useSSRContext, computed, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot } from 'vue/server-renderer';

const useDevice = () => useNuxtApp().$device;
const _sfc_main = {
  __name: "Button",
  __ssrInlineRender: true,
  props: {
    typeStyle: {
      type: Array,
      default: () => []
    },
    disabled: {
      type: Boolean,
      default: false
    },
    type: {
      type: String,
      default: "button"
    },
    onClick: {
      type: Function
    }
  },
  setup(__props) {
    const props = __props;
    const { isMobile } = useDevice();
    const classes = computed(() => ({
      button: true,
      transparent: props.typeStyle.includes("transparent"),
      icon: props.typeStyle.includes("icon"),
      blue: props.typeStyle.includes("blue"),
      blueed: props.typeStyle.includes("blueed"),
      darkeed: props.typeStyle.includes("darkeed"),
      border: props.typeStyle.includes("border"),
      small: props.typeStyle.includes("small"),
      nav: props.typeStyle.includes("nav"),
      noInteractive: props.typeStyle.includes("no-interactive")
    }));
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        class: unref(classes),
        disabled: props.disabled,
        type: props.type
      }, _attrs))} data-v-044ea30c>`);
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      if (_ctx.$slots.tooltip && !unref(isMobile)) {
        _push(`<div class="tooltip-container" data-v-044ea30c><div class="tooltip-content" data-v-044ea30c>`);
        ssrRenderSlot(_ctx.$slots, "tooltip", {}, null, _push, _parent);
        _push(`</div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</button>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Button.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-044ea30c"]]);

export { __nuxt_component_1 as _, useDevice as u };
//# sourceMappingURL=Button-00fd5b58.mjs.map
