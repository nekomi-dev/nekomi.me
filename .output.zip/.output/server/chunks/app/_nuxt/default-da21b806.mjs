import { _ as __nuxt_component_0$2 } from './nuxt-link-99c863e4.mjs';
import { ref, unref, mergeProps, useSSRContext, withCtx, createTextVNode, createVNode, openBlock, createBlock } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate, ssrRenderStyle } from 'vue/server-renderer';
import { h as __nuxt_component_1, _ as _export_sfc } from '../server.mjs';
import { u as useDevice, _ as __nuxt_component_1$1 } from './Button-00fd5b58.mjs';
import { _ as __nuxt_component_2$1 } from './Icons-1f48bf3e.mjs';
import { useRouter } from 'vue-router';
import { u as useAuth } from './useAuth-49a13afb.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'ipx';
import 'unhead';
import '@unhead/shared';

const _sfc_main$3 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$2;
  _push(ssrRenderComponent(_component_NuxtLink, mergeProps({ to: "/" }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<svg width="162" height="47" viewBox="0 0 162 47" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><rect width="162" height="47" rx="8" fill="#1C1C1C"${_scopeId}></rect><rect width="162" height="47" rx="8" fill="#0A4DFB" fill-opacity="0.15"${_scopeId}></rect><circle cx="25.5" cy="23.5" r="16.6769" fill="#1C1C1C" stroke="#366EFF" stroke-width="1.64629"${_scopeId}></circle><mask id="mask0_517_791" style="${ssrRenderStyle({ "mask-type": "alpha" })}" maskUnits="userSpaceOnUse" x="8" y="6" width="35" height="35"${_scopeId}><circle cx="25.5" cy="23.5" r="17.5" fill="#D9D9D9"${_scopeId}></circle></mask><g mask="url(#mask0_517_791)"${_scopeId}><path d="M9.86011 30.8752C9.86011 31.9869 11.033 34.9361 11.8938 36.1588C12.1386 36.5065 12.4239 36.8415 12.6023 37.2275L14.4968 41.3273C14.8306 42.0497 15.5132 42.5508 16.3045 42.6351C20.8274 43.1173 29.1813 43.6413 34.5545 42.688C40.4825 41.6362 41.1893 37.7352 41.1397 36.6373C41.1397 34.991 39.4934 33.3447 38.6702 31.6984C37.8471 30.0521 36.2008 28.4058 36.2008 27.5827C36.2008 26.7595 37.0239 25.9364 37.0239 23.4669C37.0239 20.9975 35.3776 18.5281 34.5545 17.7049C33.7314 16.8818 35.3776 14.4123 34.5545 11.9429C33.7314 9.47345 31.9395 9.17263 30.4388 9.47345C28.8246 9.79702 27.1462 11.9429 25.4999 13.5892C23.8536 15.2355 20.561 15.2355 19.7379 15.2355C18.9147 15.2355 17.2684 13.5892 15.6221 12.766C13.9758 11.9429 12.3295 12.766 11.5064 14.4123C10.6833 16.0586 11.5064 19.3512 12.3295 20.9975C13.1527 22.6438 13.1527 24.2901 13.1527 25.1132C13.1527 25.9364 9.86011 29.2289 9.86011 30.8752Z" fill="#1C1C1C" stroke="#366EFF" stroke-width="1.64629" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M26.0026 27.7429C25.8878 27.9676 26.0796 28.1449 26.38 28.2776C27.0366 28.5676 27.6476 29.0422 27.6924 29.7586C27.7026 29.9219 27.7088 30.0898 27.7088 30.2553C27.7088 31.1152 26.1108 31.0617 25.8951 30.9808C25.6632 30.8938 25.1268 30.2553 24.8954 30.5344C24.651 30.8291 24.7661 31.2064 25.3841 31.5826C26.0021 31.9588 27.3455 31.8046 27.7088 31.2225C27.8967 30.9215 28.2253 30.6181 28.4343 30.6181C28.8117 30.6181 29.8214 30.8174 30.6646 30.2553C31.3886 29.7727 31.4034 29.2611 31.3363 28.9387C31.2793 28.664 30.8258 28.5625 30.6646 28.6968C30.5034 28.8312 30.678 29.9463 29.5226 29.9597C28.3672 29.9732 28.2731 28.8984 28.2866 28.3609C28.3 27.8235 28.824 27.1921 28.7837 26.6816C28.7434 26.171 27.6735 26.3672 27.2386 26.5069C26.8293 26.6384 26.3116 27.1384 26.0026 27.7429Z" fill="#D5E1FF"${_scopeId}></path><path d="M31.2618 11.9427C30.8964 11.7797 30.3891 12.01 29.864 12.4129C28.7231 13.2882 29.1581 15.0352 30.5614 15.3491C30.8417 15.4118 31.0838 15.4473 31.2618 15.4473C32.085 15.4473 32.7042 12.5864 31.2618 11.9427Z" stroke="#366EFF" stroke-width="1.64629" stroke-linejoin="round"${_scopeId}></path><path d="M14.799 20.1744C15.6221 20.1744 16.4453 17.705 16.4453 16.8818C16.4453 16.0587 14.5571 14.3017 13.7339 15.1249C12.9108 15.948 13.9758 20.1744 14.799 20.1744Z" fill="#366EFF"${_scopeId}></path><path d="M14.7991 30.0522C15.0735 30.0522 15.6222 30.2169 15.6222 30.8754" stroke="#366EFF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M16.1667 29.4141C16.4284 29.4966 16.7043 29.9494 16.7043 30.4466" stroke="#366EFF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M17.6289 29.0039C17.9033 29.0027 18.4528 29.1648 18.4557 29.8233" stroke="#366EFF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M20.1592 29.7107C20.2334 29.3709 20.6706 28.7545 21.8252 29.0068" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M33.0037 24.595C33.3503 24.06 34.3646 23.1979 35.6486 24.0298" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M19.9568 31.5122C20.0929 30.8894 20.7387 29.7255 22.2334 30.0521" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M33.0178 25.7168C33.3644 25.1818 34.3787 24.3197 35.6628 25.1516" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M20.365 32.5574C20.5011 31.9346 21.1469 30.7706 22.6416 31.0972" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M33.032 26.8391C33.3786 26.3041 34.3929 25.442 35.6769 26.2739" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M37.0714 34.0444C36.3467 31.6827 35.1113 30.2937 37.796 30.797L40.788 35.6893C41.0176 36.0647 41.1847 36.5224 40.9849 36.9145C40.7392 37.3964 40.2389 37.6395 39.7567 37.6216C39.5203 37.6128 39.3061 37.493 39.1296 37.3356C38.5251 36.7964 37.5658 35.656 37.0714 34.0444Z" fill="#366EFF"${_scopeId}></path><path d="M18.6062 32.9031C19.2503 33.5114 20.3838 34.5436 22.3376 35.1447C24.7798 35.8961 26.068 36.0303 26.0948 36.7549C26.1217 37.4796 26.9536 34.2054 29.8252 34.0444C30.762 33.9918 31.616 34.1706 32.3452 34.4802M34.8975 37.1843C34.8252 36.3164 33.8513 35.1195 32.3452 34.4802M32.3452 34.4802C32.4535 34.1739 32.9759 33.148 34.1997 31.4948C34.6713 30.8577 35.0704 30.341 35.3951 29.9342C35.9675 29.2171 36.8459 29.1527 37.4058 29.8797C37.7899 30.3785 38.0677 30.8479 37.796 30.797M37.796 30.797C35.1113 30.2937 36.3467 31.6827 37.0714 34.0444C37.5658 35.656 38.5251 36.7964 39.1296 37.3356C39.3061 37.493 39.5203 37.6128 39.7567 37.6216C40.2389 37.6395 40.7392 37.3964 40.9849 36.9145C41.1847 36.5224 41.0176 36.0647 40.788 35.6893L37.796 30.797Z" stroke="#366EFF" stroke-width="1.64629" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M21.031 26.809C21.2348 26.2753 21.9452 25.3679 23.1563 26.0084" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M30.1873 24.1452C30.5221 23.4027 31.1917 22.7477 32.1379 23.0679" stroke="#D5E1FF" stroke-width="0.493888" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path><path d="M12.3296 25.9364C13.4271 25.3877 15.9514 24.6194 17.2685 25.9364C18.9148 27.5827 20.5611 29.229 19.7379 30.8753C18.9148 32.5216 16.4453 34.1679 14.799 32.5216C13.482 31.2046 13.1527 30.3265 13.1527 30.0521" stroke="#366EFF" stroke-width="0.820752" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></g><path d="M58.0795 24.4318V32H54.4489V18.9091H57.9091V21.2188H58.0625C58.3523 20.4574 58.8381 19.8551 59.5199 19.4119C60.2017 18.9631 61.0284 18.7386 62 18.7386C62.9091 18.7386 63.7017 18.9375 64.3778 19.3352C65.054 19.733 65.5795 20.3011 65.9545 21.0398C66.3295 21.7727 66.517 22.6477 66.517 23.6648V32H62.8864V24.3125C62.892 23.5114 62.6875 22.8864 62.2727 22.4375C61.858 21.983 61.2869 21.7557 60.5597 21.7557C60.071 21.7557 59.6392 21.8608 59.2642 22.071C58.8949 22.2812 58.6051 22.5881 58.3949 22.9915C58.1903 23.3892 58.0852 23.8693 58.0795 24.4318ZM78.2245 32.2557C76.8779 32.2557 75.7188 31.983 74.7472 31.4375C73.7813 30.8864 73.037 30.108 72.5142 29.1023C71.9915 28.0909 71.7301 26.8949 71.7301 25.5142C71.7301 24.1676 71.9915 22.9858 72.5142 21.9688C73.037 20.9517 73.7728 20.1591 74.7216 19.5909C75.6762 19.0227 76.7955 18.7386 78.0796 18.7386C78.9432 18.7386 79.7472 18.8778 80.4915 19.1562C81.2415 19.429 81.8949 19.8409 82.4517 20.392C83.0142 20.9432 83.4517 21.6364 83.7642 22.4716C84.0767 23.3011 84.233 24.2727 84.233 25.3864V26.3835H73.179V24.1335H80.8154C80.8154 23.6108 80.7017 23.1477 80.4745 22.7443C80.2472 22.3409 79.9318 22.0256 79.5284 21.7983C79.1307 21.5653 78.6676 21.4489 78.1392 21.4489C77.5881 21.4489 77.0995 21.5767 76.6733 21.8324C76.2529 22.0824 75.9233 22.4205 75.6847 22.8466C75.4461 23.267 75.3239 23.7358 75.3182 24.2528V26.392C75.3182 27.0398 75.4375 27.5994 75.6762 28.071C75.9205 28.5426 76.2642 28.9062 76.7074 29.1619C77.1506 29.4176 77.6762 29.5455 78.2841 29.5455C78.6875 29.5455 79.0568 29.4886 79.3921 29.375C79.7273 29.2614 80.0142 29.0909 80.2529 28.8636C80.4915 28.6364 80.6733 28.358 80.7983 28.0284L84.1563 28.25C83.9858 29.0568 83.6364 29.7614 83.108 30.3636C82.5853 30.9602 81.9091 31.4261 81.0796 31.7614C80.2557 32.0909 79.304 32.2557 78.2245 32.2557ZM92.7721 28.233L92.7806 23.8778H93.309L97.5022 18.9091H101.67L96.0363 25.4886H95.1755L92.7721 28.233ZM89.4823 32V14.5455H93.113V32H89.4823ZM97.6641 32L93.8118 26.2983L96.2323 23.733L101.917 32H97.6641ZM111.707 32.2557C110.383 32.2557 109.238 31.9744 108.272 31.4119C107.312 30.8437 106.57 30.054 106.048 29.0426C105.525 28.0256 105.264 26.8466 105.264 25.5057C105.264 24.1534 105.525 22.9716 106.048 21.9602C106.57 20.9432 107.312 20.1534 108.272 19.5909C109.238 19.0227 110.383 18.7386 111.707 18.7386C113.031 18.7386 114.173 19.0227 115.133 19.5909C116.099 20.1534 116.843 20.9432 117.366 21.9602C117.889 22.9716 118.15 24.1534 118.15 25.5057C118.15 26.8466 117.889 28.0256 117.366 29.0426C116.843 30.054 116.099 30.8437 115.133 31.4119C114.173 31.9744 113.031 32.2557 111.707 32.2557ZM111.724 29.4432C112.326 29.4432 112.829 29.2727 113.232 28.9318C113.636 28.5852 113.94 28.1136 114.144 27.517C114.354 26.9205 114.46 26.2415 114.46 25.4801C114.46 24.7188 114.354 24.0398 114.144 23.4432C113.94 22.8466 113.636 22.375 113.232 22.0284C112.829 21.6818 112.326 21.5085 111.724 21.5085C111.116 21.5085 110.604 21.6818 110.19 22.0284C109.781 22.375 109.471 22.8466 109.261 23.4432C109.056 24.0398 108.954 24.7188 108.954 25.4801C108.954 26.2415 109.056 26.9205 109.261 27.517C109.471 28.1136 109.781 28.5852 110.19 28.9318C110.604 29.2727 111.116 29.4432 111.724 29.4432ZM123.391 32V18.9091H126.851V21.2188H127.004C127.277 20.4517 127.732 19.8466 128.368 19.4034C129.004 18.9602 129.766 18.7386 130.652 18.7386C131.55 18.7386 132.314 18.9631 132.945 19.4119C133.575 19.8551 133.996 20.4574 134.206 21.2188H134.342C134.609 20.4688 135.092 19.8693 135.791 19.4205C136.496 18.9659 137.328 18.7386 138.288 18.7386C139.51 18.7386 140.502 19.1278 141.263 19.9062C142.03 20.679 142.413 21.7756 142.413 23.196V32H138.791V23.9119C138.791 23.1847 138.598 22.6392 138.212 22.2756C137.825 21.9119 137.342 21.7301 136.763 21.7301C136.104 21.7301 135.59 21.9403 135.22 22.3608C134.851 22.7756 134.666 23.3239 134.666 24.0057V32H131.146V23.8352C131.146 23.1932 130.962 22.6818 130.592 22.3011C130.229 21.9205 129.749 21.7301 129.152 21.7301C128.749 21.7301 128.385 21.8324 128.061 22.0369C127.743 22.2358 127.49 22.517 127.303 22.8807C127.115 23.2386 127.021 23.6591 127.021 24.142V32H123.391ZM148.161 32V18.9091H151.792V32H148.161ZM149.985 17.2216C149.445 17.2216 148.982 17.0426 148.596 16.6847C148.215 16.321 148.025 15.8864 148.025 15.3807C148.025 14.8807 148.215 14.4517 148.596 14.0938C148.982 13.7301 149.445 13.5483 149.985 13.5483C150.525 13.5483 150.985 13.7301 151.366 14.0938C151.752 14.4517 151.945 14.8807 151.945 15.3807C151.945 15.8864 151.752 16.321 151.366 16.6847C150.985 17.0426 150.525 17.2216 149.985 17.2216Z" fill="#366EFF"${_scopeId}></path></svg>`);
      } else {
        return [
          (openBlock(), createBlock("svg", {
            width: "162",
            height: "47",
            viewBox: "0 0 162 47",
            fill: "none",
            xmlns: "http://www.w3.org/2000/svg"
          }, [
            createVNode("rect", {
              width: "162",
              height: "47",
              rx: "8",
              fill: "#1C1C1C"
            }),
            createVNode("rect", {
              width: "162",
              height: "47",
              rx: "8",
              fill: "#0A4DFB",
              "fill-opacity": "0.15"
            }),
            createVNode("circle", {
              cx: "25.5",
              cy: "23.5",
              r: "16.6769",
              fill: "#1C1C1C",
              stroke: "#366EFF",
              "stroke-width": "1.64629"
            }),
            createVNode("mask", {
              id: "mask0_517_791",
              style: { "mask-type": "alpha" },
              maskUnits: "userSpaceOnUse",
              x: "8",
              y: "6",
              width: "35",
              height: "35"
            }, [
              createVNode("circle", {
                cx: "25.5",
                cy: "23.5",
                r: "17.5",
                fill: "#D9D9D9"
              })
            ]),
            createVNode("g", { mask: "url(#mask0_517_791)" }, [
              createVNode("path", {
                d: "M9.86011 30.8752C9.86011 31.9869 11.033 34.9361 11.8938 36.1588C12.1386 36.5065 12.4239 36.8415 12.6023 37.2275L14.4968 41.3273C14.8306 42.0497 15.5132 42.5508 16.3045 42.6351C20.8274 43.1173 29.1813 43.6413 34.5545 42.688C40.4825 41.6362 41.1893 37.7352 41.1397 36.6373C41.1397 34.991 39.4934 33.3447 38.6702 31.6984C37.8471 30.0521 36.2008 28.4058 36.2008 27.5827C36.2008 26.7595 37.0239 25.9364 37.0239 23.4669C37.0239 20.9975 35.3776 18.5281 34.5545 17.7049C33.7314 16.8818 35.3776 14.4123 34.5545 11.9429C33.7314 9.47345 31.9395 9.17263 30.4388 9.47345C28.8246 9.79702 27.1462 11.9429 25.4999 13.5892C23.8536 15.2355 20.561 15.2355 19.7379 15.2355C18.9147 15.2355 17.2684 13.5892 15.6221 12.766C13.9758 11.9429 12.3295 12.766 11.5064 14.4123C10.6833 16.0586 11.5064 19.3512 12.3295 20.9975C13.1527 22.6438 13.1527 24.2901 13.1527 25.1132C13.1527 25.9364 9.86011 29.2289 9.86011 30.8752Z",
                fill: "#1C1C1C",
                stroke: "#366EFF",
                "stroke-width": "1.64629",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M26.0026 27.7429C25.8878 27.9676 26.0796 28.1449 26.38 28.2776C27.0366 28.5676 27.6476 29.0422 27.6924 29.7586C27.7026 29.9219 27.7088 30.0898 27.7088 30.2553C27.7088 31.1152 26.1108 31.0617 25.8951 30.9808C25.6632 30.8938 25.1268 30.2553 24.8954 30.5344C24.651 30.8291 24.7661 31.2064 25.3841 31.5826C26.0021 31.9588 27.3455 31.8046 27.7088 31.2225C27.8967 30.9215 28.2253 30.6181 28.4343 30.6181C28.8117 30.6181 29.8214 30.8174 30.6646 30.2553C31.3886 29.7727 31.4034 29.2611 31.3363 28.9387C31.2793 28.664 30.8258 28.5625 30.6646 28.6968C30.5034 28.8312 30.678 29.9463 29.5226 29.9597C28.3672 29.9732 28.2731 28.8984 28.2866 28.3609C28.3 27.8235 28.824 27.1921 28.7837 26.6816C28.7434 26.171 27.6735 26.3672 27.2386 26.5069C26.8293 26.6384 26.3116 27.1384 26.0026 27.7429Z",
                fill: "#D5E1FF"
              }),
              createVNode("path", {
                d: "M31.2618 11.9427C30.8964 11.7797 30.3891 12.01 29.864 12.4129C28.7231 13.2882 29.1581 15.0352 30.5614 15.3491C30.8417 15.4118 31.0838 15.4473 31.2618 15.4473C32.085 15.4473 32.7042 12.5864 31.2618 11.9427Z",
                stroke: "#366EFF",
                "stroke-width": "1.64629",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M14.799 20.1744C15.6221 20.1744 16.4453 17.705 16.4453 16.8818C16.4453 16.0587 14.5571 14.3017 13.7339 15.1249C12.9108 15.948 13.9758 20.1744 14.799 20.1744Z",
                fill: "#366EFF"
              }),
              createVNode("path", {
                d: "M14.7991 30.0522C15.0735 30.0522 15.6222 30.2169 15.6222 30.8754",
                stroke: "#366EFF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M16.1667 29.4141C16.4284 29.4966 16.7043 29.9494 16.7043 30.4466",
                stroke: "#366EFF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M17.6289 29.0039C17.9033 29.0027 18.4528 29.1648 18.4557 29.8233",
                stroke: "#366EFF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M20.1592 29.7107C20.2334 29.3709 20.6706 28.7545 21.8252 29.0068",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M33.0037 24.595C33.3503 24.06 34.3646 23.1979 35.6486 24.0298",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M19.9568 31.5122C20.0929 30.8894 20.7387 29.7255 22.2334 30.0521",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M33.0178 25.7168C33.3644 25.1818 34.3787 24.3197 35.6628 25.1516",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M20.365 32.5574C20.5011 31.9346 21.1469 30.7706 22.6416 31.0972",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M33.032 26.8391C33.3786 26.3041 34.3929 25.442 35.6769 26.2739",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M37.0714 34.0444C36.3467 31.6827 35.1113 30.2937 37.796 30.797L40.788 35.6893C41.0176 36.0647 41.1847 36.5224 40.9849 36.9145C40.7392 37.3964 40.2389 37.6395 39.7567 37.6216C39.5203 37.6128 39.3061 37.493 39.1296 37.3356C38.5251 36.7964 37.5658 35.656 37.0714 34.0444Z",
                fill: "#366EFF"
              }),
              createVNode("path", {
                d: "M18.6062 32.9031C19.2503 33.5114 20.3838 34.5436 22.3376 35.1447C24.7798 35.8961 26.068 36.0303 26.0948 36.7549C26.1217 37.4796 26.9536 34.2054 29.8252 34.0444C30.762 33.9918 31.616 34.1706 32.3452 34.4802M34.8975 37.1843C34.8252 36.3164 33.8513 35.1195 32.3452 34.4802M32.3452 34.4802C32.4535 34.1739 32.9759 33.148 34.1997 31.4948C34.6713 30.8577 35.0704 30.341 35.3951 29.9342C35.9675 29.2171 36.8459 29.1527 37.4058 29.8797C37.7899 30.3785 38.0677 30.8479 37.796 30.797M37.796 30.797C35.1113 30.2937 36.3467 31.6827 37.0714 34.0444C37.5658 35.656 38.5251 36.7964 39.1296 37.3356C39.3061 37.493 39.5203 37.6128 39.7567 37.6216C40.2389 37.6395 40.7392 37.3964 40.9849 36.9145C41.1847 36.5224 41.0176 36.0647 40.788 35.6893L37.796 30.797Z",
                stroke: "#366EFF",
                "stroke-width": "1.64629",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M21.031 26.809C21.2348 26.2753 21.9452 25.3679 23.1563 26.0084",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M30.1873 24.1452C30.5221 23.4027 31.1917 22.7477 32.1379 23.0679",
                stroke: "#D5E1FF",
                "stroke-width": "0.493888",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              }),
              createVNode("path", {
                d: "M12.3296 25.9364C13.4271 25.3877 15.9514 24.6194 17.2685 25.9364C18.9148 27.5827 20.5611 29.229 19.7379 30.8753C18.9148 32.5216 16.4453 34.1679 14.799 32.5216C13.482 31.2046 13.1527 30.3265 13.1527 30.0521",
                stroke: "#366EFF",
                "stroke-width": "0.820752",
                "stroke-linecap": "round",
                "stroke-linejoin": "round"
              })
            ]),
            createVNode("path", {
              d: "M58.0795 24.4318V32H54.4489V18.9091H57.9091V21.2188H58.0625C58.3523 20.4574 58.8381 19.8551 59.5199 19.4119C60.2017 18.9631 61.0284 18.7386 62 18.7386C62.9091 18.7386 63.7017 18.9375 64.3778 19.3352C65.054 19.733 65.5795 20.3011 65.9545 21.0398C66.3295 21.7727 66.517 22.6477 66.517 23.6648V32H62.8864V24.3125C62.892 23.5114 62.6875 22.8864 62.2727 22.4375C61.858 21.983 61.2869 21.7557 60.5597 21.7557C60.071 21.7557 59.6392 21.8608 59.2642 22.071C58.8949 22.2812 58.6051 22.5881 58.3949 22.9915C58.1903 23.3892 58.0852 23.8693 58.0795 24.4318ZM78.2245 32.2557C76.8779 32.2557 75.7188 31.983 74.7472 31.4375C73.7813 30.8864 73.037 30.108 72.5142 29.1023C71.9915 28.0909 71.7301 26.8949 71.7301 25.5142C71.7301 24.1676 71.9915 22.9858 72.5142 21.9688C73.037 20.9517 73.7728 20.1591 74.7216 19.5909C75.6762 19.0227 76.7955 18.7386 78.0796 18.7386C78.9432 18.7386 79.7472 18.8778 80.4915 19.1562C81.2415 19.429 81.8949 19.8409 82.4517 20.392C83.0142 20.9432 83.4517 21.6364 83.7642 22.4716C84.0767 23.3011 84.233 24.2727 84.233 25.3864V26.3835H73.179V24.1335H80.8154C80.8154 23.6108 80.7017 23.1477 80.4745 22.7443C80.2472 22.3409 79.9318 22.0256 79.5284 21.7983C79.1307 21.5653 78.6676 21.4489 78.1392 21.4489C77.5881 21.4489 77.0995 21.5767 76.6733 21.8324C76.2529 22.0824 75.9233 22.4205 75.6847 22.8466C75.4461 23.267 75.3239 23.7358 75.3182 24.2528V26.392C75.3182 27.0398 75.4375 27.5994 75.6762 28.071C75.9205 28.5426 76.2642 28.9062 76.7074 29.1619C77.1506 29.4176 77.6762 29.5455 78.2841 29.5455C78.6875 29.5455 79.0568 29.4886 79.3921 29.375C79.7273 29.2614 80.0142 29.0909 80.2529 28.8636C80.4915 28.6364 80.6733 28.358 80.7983 28.0284L84.1563 28.25C83.9858 29.0568 83.6364 29.7614 83.108 30.3636C82.5853 30.9602 81.9091 31.4261 81.0796 31.7614C80.2557 32.0909 79.304 32.2557 78.2245 32.2557ZM92.7721 28.233L92.7806 23.8778H93.309L97.5022 18.9091H101.67L96.0363 25.4886H95.1755L92.7721 28.233ZM89.4823 32V14.5455H93.113V32H89.4823ZM97.6641 32L93.8118 26.2983L96.2323 23.733L101.917 32H97.6641ZM111.707 32.2557C110.383 32.2557 109.238 31.9744 108.272 31.4119C107.312 30.8437 106.57 30.054 106.048 29.0426C105.525 28.0256 105.264 26.8466 105.264 25.5057C105.264 24.1534 105.525 22.9716 106.048 21.9602C106.57 20.9432 107.312 20.1534 108.272 19.5909C109.238 19.0227 110.383 18.7386 111.707 18.7386C113.031 18.7386 114.173 19.0227 115.133 19.5909C116.099 20.1534 116.843 20.9432 117.366 21.9602C117.889 22.9716 118.15 24.1534 118.15 25.5057C118.15 26.8466 117.889 28.0256 117.366 29.0426C116.843 30.054 116.099 30.8437 115.133 31.4119C114.173 31.9744 113.031 32.2557 111.707 32.2557ZM111.724 29.4432C112.326 29.4432 112.829 29.2727 113.232 28.9318C113.636 28.5852 113.94 28.1136 114.144 27.517C114.354 26.9205 114.46 26.2415 114.46 25.4801C114.46 24.7188 114.354 24.0398 114.144 23.4432C113.94 22.8466 113.636 22.375 113.232 22.0284C112.829 21.6818 112.326 21.5085 111.724 21.5085C111.116 21.5085 110.604 21.6818 110.19 22.0284C109.781 22.375 109.471 22.8466 109.261 23.4432C109.056 24.0398 108.954 24.7188 108.954 25.4801C108.954 26.2415 109.056 26.9205 109.261 27.517C109.471 28.1136 109.781 28.5852 110.19 28.9318C110.604 29.2727 111.116 29.4432 111.724 29.4432ZM123.391 32V18.9091H126.851V21.2188H127.004C127.277 20.4517 127.732 19.8466 128.368 19.4034C129.004 18.9602 129.766 18.7386 130.652 18.7386C131.55 18.7386 132.314 18.9631 132.945 19.4119C133.575 19.8551 133.996 20.4574 134.206 21.2188H134.342C134.609 20.4688 135.092 19.8693 135.791 19.4205C136.496 18.9659 137.328 18.7386 138.288 18.7386C139.51 18.7386 140.502 19.1278 141.263 19.9062C142.03 20.679 142.413 21.7756 142.413 23.196V32H138.791V23.9119C138.791 23.1847 138.598 22.6392 138.212 22.2756C137.825 21.9119 137.342 21.7301 136.763 21.7301C136.104 21.7301 135.59 21.9403 135.22 22.3608C134.851 22.7756 134.666 23.3239 134.666 24.0057V32H131.146V23.8352C131.146 23.1932 130.962 22.6818 130.592 22.3011C130.229 21.9205 129.749 21.7301 129.152 21.7301C128.749 21.7301 128.385 21.8324 128.061 22.0369C127.743 22.2358 127.49 22.517 127.303 22.8807C127.115 23.2386 127.021 23.6591 127.021 24.142V32H123.391ZM148.161 32V18.9091H151.792V32H148.161ZM149.985 17.2216C149.445 17.2216 148.982 17.0426 148.596 16.6847C148.215 16.321 148.025 15.8864 148.025 15.3807C148.025 14.8807 148.215 14.4517 148.596 14.0938C148.982 13.7301 149.445 13.5483 149.985 13.5483C150.525 13.5483 150.985 13.7301 151.366 14.0938C151.752 14.4517 151.945 14.8807 151.945 15.3807C151.945 15.8864 151.752 16.321 151.366 16.6847C150.985 17.0426 150.525 17.2216 149.985 17.2216Z",
              fill: "#366EFF"
            })
          ]))
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Logo.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$2 = {
  __name: "Navigation",
  __ssrInlineRender: true,
  setup(__props) {
    const { isMobile } = useDevice();
    const router = useRouter();
    const { isAuth, user, logout } = useAuth();
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_UILogo = __nuxt_component_0$1;
      const _component_UIButton = __nuxt_component_1$1;
      const _component_IconIcons = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "navigation" }, _attrs))} data-v-1b58fecb><div class="navigation__container" data-v-1b58fecb><div class="navigation__container-item" data-v-1b58fecb>`);
      _push(ssrRenderComponent(_component_UILogo, { class: "navigation__logo" }, null, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041A\u0430\u0442\u0430\u043B\u043E\u0433`);
          } else {
            return [
              createTextVNode("\u041A\u0430\u0442\u0430\u043B\u043E\u0433")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041D\u043E\u0432\u043E\u0441\u0442\u0438`);
          } else {
            return [
              createTextVNode("\u041D\u043E\u0432\u043E\u0441\u0442\u0438")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u0420\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0435`);
          } else {
            return [
              createTextVNode("\u0420\u0430\u0441\u043F\u0438\u0441\u0430\u043D\u0438\u0435")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442`);
          } else {
            return [
              createTextVNode("\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044C \u043F\u0440\u043E\u0435\u043A\u0442")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="navigation__container-item" data-v-1b58fecb>`);
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav', 'icon']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              random: "",
              size: 18,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_IconIcons, {
                random: "",
                size: 18,
                color: "var(--white)"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav', 'icon']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              search: "",
              size: 18,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_IconIcons, {
                search: "",
                size: 18,
                color: "var(--white)"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['nav', 'icon']" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              settings: "",
              size: 18,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_IconIcons, {
                settings: "",
                size: 18,
                color: "var(--white)"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      if (!unref(isAuth)) {
        _push(ssrRenderComponent(_component_UIButton, {
          onClick: ($event) => unref(router).push("/auth"),
          typeStyle: "['blue']"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`\u0412\u043E\u0439\u0442\u0438`);
            } else {
              return [
                createTextVNode("\u0412\u043E\u0439\u0442\u0438")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="navigation__container-item-auth" data-v-1b58fecb>`);
      if (unref(isAuth) && !unref(isMobile)) {
        _push(`<span data-v-1b58fecb>${ssrInterpolate((_a = unref(user)) == null ? void 0 : _a.name)}</span>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(isAuth)) {
        _push(ssrRenderComponent(_component_UIButton, {
          onClick: unref(logout),
          typeStyle: "['blue']"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(` \u0412\u044B\u0439\u0442\u0438 `);
            } else {
              return [
                createTextVNode(" \u0412\u044B\u0439\u0442\u0438 ")
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      _push(ssrRenderComponent(_component_UIButton, {
        class: "navigation__container-item-burger",
        typeStyle: "['icon', 'blue']"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_IconIcons, {
              burger: "",
              size: 18,
              color: "var(--white)"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode(_component_IconIcons, {
                burger: "",
                size: 18,
                color: "var(--white)"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Block/Navigation.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-1b58fecb"]]);
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<span${ssrRenderAttrs(mergeProps({ class: "loader" }, _attrs))} data-v-ffb0fa9c></span>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Loader.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-ffb0fa9c"]]);
const _sfc_main = {
  __name: "default",
  __ssrInlineRender: true,
  setup(__props) {
    const loading = ref(false);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockNavigation = __nuxt_component_0;
      const _component_NuxtPage = __nuxt_component_1;
      const _component_UILoader = __nuxt_component_2;
      if (unref(loading)) {
        _push(`<div${ssrRenderAttrs(_attrs)}>`);
        _push(ssrRenderComponent(_component_BlockNavigation, null, null, _parent));
        _push(ssrRenderComponent(_component_NuxtPage, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<div${ssrRenderAttrs(mergeProps({ class: "loaderScreen" }, _attrs))}>`);
        _push(ssrRenderComponent(_component_UILoader, null, null, _parent));
        _push(`</div>`);
      }
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=default-da21b806.mjs.map
