import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_2$1 } from './Icons-1f48bf3e.mjs';
import { u as useDevice, _ as __nuxt_component_1$1 } from './Button-00fd5b58.mjs';
import { ref, watchEffect, mergeProps, useSSRContext, computed, unref, withCtx, createTextVNode, createVNode, defineModel } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderClass, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { r as resolveUnrefHeadInput, u as useHead, _ as _export_sfc } from '../server.mjs';
import script from './multiselect.esm-4982f7be.mjs';
import { _ as __nuxt_component_0$4 } from './nuxt-link-99c863e4.mjs';
import { composableNames, unpackMeta } from '@unhead/shared';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import 'vue-router';

const coreComposableNames = [
  "injectHead"
];
({
  "@unhead/vue": [...coreComposableNames, ...composableNames]
});
function useSeoMeta(input, options) {
  const headInput = ref({});
  watchEffect(() => {
    const resolvedMeta = resolveUnrefHeadInput(input);
    const { title, titleTemplate, ...meta } = resolvedMeta;
    headInput.value = {
      title,
      titleTemplate,
      meta: unpackMeta(meta)
    };
  });
  return useHead(headInput, options);
}

const _imports_0$1 = "" + publicAssetsURL("anime_poster.png");
const _sfc_main$6 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  const _component_IconIcons = __nuxt_component_2$1;
  const _component_UIButton = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "banner" }, _attrs))} data-v-11be3a76><div class="banner__info" data-v-11be3a76><div class="banner__info-text" data-v-11be3a76><h1 class="banner__info-title" data-v-11be3a76> \u041F\u0435\u0440\u0435\u0432\u043E\u043F\u043B\u043E\u0442\u0438\u043B\u0441\u044F \u0432 \u0441\u0435\u0434\u044C\u043C\u043E\u0433\u043E \u043F\u0440\u0438\u043D\u0446\u0430, \u0442\u0430\u043A \u0447\u0442\u043E \u044F \u0431\u0443\u0434\u0443 \u0441\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u0441\u0442\u0432\u043E\u0432\u0430\u0442\u044C \u0441\u0432\u043E\u044E \u043C\u0430\u0433\u0438\u044E, \u043A\u0430\u043A \u0437\u0430\u0445\u043E\u0447\u0443 </h1><div class="banner__info-tags" data-v-11be3a76><div class="banner__info-tag" data-v-11be3a76><span data-v-11be3a76>16+</span><div class="banner__info-tag-text" data-v-11be3a76><span data-v-11be3a76>\u0412\u0435\u0441\u043D\u0430</span>`);
  _push(ssrRenderComponent(_component_IconIcons, {
    dot: "",
    size: 3,
    color: "var(--white)"
  }, null, _parent));
  _push(`<span data-v-11be3a76>2024</span>`);
  _push(ssrRenderComponent(_component_IconIcons, {
    dot: "",
    size: 3,
    color: "var(--white)"
  }, null, _parent));
  _push(`<span data-v-11be3a76>12 \u0441\u0435\u0440\u0438\u0439</span></div></div><div class="banner__info-tag" data-v-11be3a76><div class="banner__info-tag-text" data-v-11be3a76><span data-v-11be3a76>\u041F\u0440\u0438\u043A\u043B\u044E\u0447\u0435\u043D\u0438\u044F</span>`);
  _push(ssrRenderComponent(_component_IconIcons, {
    dot: "",
    size: 3,
    color: "var(--white-alpha50)"
  }, null, _parent));
  _push(`<span data-v-11be3a76>\u0418\u0441\u0435\u043A\u0430\u0439</span>`);
  _push(ssrRenderComponent(_component_IconIcons, {
    dot: "",
    size: 3,
    color: "var(--white-alpha50)"
  }, null, _parent));
  _push(`<span data-v-11be3a76>\u0424\u044D\u043D\u0442\u0435\u0437\u0438</span></div></div></div></div><div class="banner__info-buttons" data-v-11be3a76>`);
  _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon', 'darkeed']" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`\u0421\u043C\u043E\u0442\u0440\u0435\u0442\u044C`);
        _push2(ssrRenderComponent(_component_IconIcons, {
          goto: "",
          size: 10,
          color: "var(--white)"
        }, null, _parent2, _scopeId));
      } else {
        return [
          createTextVNode("\u0421\u043C\u043E\u0442\u0440\u0435\u0442\u044C"),
          createVNode(_component_IconIcons, {
            goto: "",
            size: 10,
            color: "var(--white)"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon', 'darkeed']" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_IconIcons, {
          favorite: "",
          size: 16,
          color: "var(--white)"
        }, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_IconIcons, {
            favorite: "",
            size: 16,
            color: "var(--white)"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon', 'darkeed']" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_IconIcons, {
          newWindow: "",
          size: 16,
          color: "var(--white)"
        }, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_IconIcons, {
            newWindow: "",
            size: 16,
            color: "var(--white)"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div><div class="banner__buttons" data-v-11be3a76>`);
  _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon']" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_IconIcons, {
          info: "",
          size: 16,
          color: "var(--white)"
        }, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_IconIcons, {
            info: "",
            size: 16,
            color: "var(--white)"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon', 'blueed', 'no-interactive']" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_IconIcons, {
          checked: "",
          size: 16,
          color: "var(--white)"
        }, null, _parent2, _scopeId));
        _push2(`\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u043E`);
      } else {
        return [
          createVNode(_component_IconIcons, {
            checked: "",
            size: 16,
            color: "var(--white)"
          }),
          createTextVNode("\u0417\u0430\u0432\u0435\u0440\u0448\u0435\u043D\u043D\u043E")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="banner__img" data-v-11be3a76><img${ssrRenderAttr("src", _imports_0$1)} alt="" data-v-11be3a76></div></div>`);
}
const _sfc_setup$6 = _sfc_main$6.setup;
_sfc_main$6.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Block/Banner.vue");
  return _sfc_setup$6 ? _sfc_setup$6(props, ctx) : void 0;
};
const __nuxt_component_0$3 = /* @__PURE__ */ _export_sfc(_sfc_main$6, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-11be3a76"]]);
const _sfc_main$5 = {
  __name: "Select",
  __ssrInlineRender: true,
  props: {
    options: {
      type: Array,
      required: true
    },
    placeholder: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    const model = defineModel();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_MultiSelect = script;
      _push(ssrRenderComponent(_component_MultiSelect, mergeProps({
        modelValue: model.value,
        "onUpdate:modelValue": ($event) => model.value = $event,
        options: props.options,
        optionLabel: "name",
        filter: "",
        placeholder: props.placeholder,
        maxSelectedLabels: 2
      }, _attrs), null, _parent));
    };
  }
};
const _sfc_setup$5 = _sfc_main$5.setup;
_sfc_main$5.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Select.vue");
  return _sfc_setup$5 ? _sfc_setup$5(props, ctx) : void 0;
};
const __nuxt_component_0$2 = _sfc_main$5;
const _sfc_main$4 = {
  __name: "Filter",
  __ssrInlineRender: true,
  setup(__props) {
    const types = ["TV", "ONA", "OVA", "\u0424\u0438\u043B\u044C\u043C", "\u0421\u043F\u044D\u0448\u043B", "\u041C\u0443\u0437\u044B\u043A\u0430"];
    const statuses = ["\u0410\u043D\u043E\u043D\u0441", "\u041E\u043D\u0433\u043E\u0438\u043D\u0433", "\u0417\u0430\u0432\u0435\u0440\u0448\u0451\u043D"];
    const seasons = ["\u041E\u0441\u0435\u043D\u044C", "\u0417\u0438\u043C\u0430", "\u0412\u0435\u0441\u043D\u0430", "\u041B\u0435\u0442\u043E"];
    const ratings = ["0+", "6+", "12+", "16+", "18+"];
    const filters = ref({
      currentType: null,
      currentStatus: null,
      currentSeason: null,
      currentRating: null,
      currentGenre: null,
      currentSort: null,
      releasePeriodFrom: null,
      releasePeriodTo: null
    });
    const isAnyFilterActive = computed(() => {
      return Object.values(filters.value).some((value) => value !== null);
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_UISelect = __nuxt_component_0$2;
      const _component_IconIcons = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "filter" }, _attrs))} data-v-5dd1e269><div class="filder__head" data-v-5dd1e269><h2 class="filter__title" data-v-5dd1e269>\u0424\u0438\u043B\u044C\u0442\u0440\u044B</h2><p class="filter__description" data-v-5dd1e269> \u0412\u043E\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435\u0441\u044C \u0444\u0438\u043B\u044C\u0442\u0440\u0430\u043C\u0438, \u0447\u0442\u043E\u0431\u044B \u043D\u0430\u0439\u0442\u0438 \u0430\u043D\u0438\u043C\u0435 \u043F\u043E \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u0430\u043C </p></div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u0416\u0430\u043D\u0440\u044B</label><hr data-v-5dd1e269></div>`);
      _push(ssrRenderComponent(_component_UISelect, {
        placeholder: "\u0412\u044B\u0431\u0435\u0440\u0438\u0442\u0435 \u0436\u0430\u043D\u0440\u044B",
        modelValue: unref(filters).currentGenre,
        "onUpdate:modelValue": ($event) => unref(filters).currentGenre = $event,
        options: [
          { name: "\u0421\u0451\u043D\u044D\u043D" },
          { name: "\u041A\u043E\u043C\u0435\u0434\u0438\u044F" },
          { name: "\u0420\u043E\u043C\u0430\u043D\u0442\u0438\u043A\u0430" }
        ]
      }, null, _parent));
      _push(`</div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u0422\u0438\u043F</label><hr data-v-5dd1e269></div><div class="filter__buttons" data-v-5dd1e269><!--[-->`);
      ssrRenderList(types, (type) => {
        _push(`<button class="${ssrRenderClass([{ "filter__button--active": unref(filters).currentType === type }, "filter__button"])}" data-v-5dd1e269>${ssrInterpolate(type)}</button>`);
      });
      _push(`<!--]--></div></div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u0421\u0442\u0430\u0442\u0443\u0441</label><hr data-v-5dd1e269></div><div class="filter__buttons" data-v-5dd1e269><!--[-->`);
      ssrRenderList(statuses, (status) => {
        _push(`<button class="${ssrRenderClass([{
          "filter__button--active": unref(filters).currentStatus === status
        }, "filter__button"])}" data-v-5dd1e269>${ssrInterpolate(status)}</button>`);
      });
      _push(`<!--]--></div></div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u0421\u0435\u0437\u043E\u043D</label><hr data-v-5dd1e269></div><div class="filter__buttons" data-v-5dd1e269><!--[-->`);
      ssrRenderList(seasons, (season) => {
        _push(`<button class="${ssrRenderClass([{
          "filter__button--active": unref(filters).currentSeason === season
        }, "filter__button"])}" data-v-5dd1e269>${ssrInterpolate(season)}</button>`);
      });
      _push(`<!--]--></div></div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430</label><hr data-v-5dd1e269></div>`);
      _push(ssrRenderComponent(_component_UISelect, {
        placeholder: "\u0421\u043F\u043E\u0441\u043E\u0431 \u0441\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0438...",
        options: [
          { name: "\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430 1" },
          { name: "\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430 2" },
          { name: "\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430 3" }
        ],
        modelValue: unref(filters).currentSort,
        "onUpdate:modelValue": ($event) => unref(filters).currentSort = $event
      }, null, _parent));
      _push(`</div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u0412\u043E\u0437\u0440\u0430\u0441\u0442\u043D\u043E\u0439 \u0440\u0435\u0439\u0442\u0438\u043D\u0433</label><hr data-v-5dd1e269></div><div class="filter__buttons" data-v-5dd1e269><!--[-->`);
      ssrRenderList(ratings, (rating) => {
        _push(`<button class="${ssrRenderClass([{
          "filter__button--active": unref(filters).currentRating === rating
        }, "filter__button"])}" data-v-5dd1e269>${ssrInterpolate(rating)}</button>`);
      });
      _push(`<!--]--></div></div><div class="filter__section" data-v-5dd1e269><div class="filter__section-name" data-v-5dd1e269><label data-v-5dd1e269>\u041F\u0435\u0440\u0438\u043E\u0434 \u0432\u044B\u0445\u043E\u0434\u0430</label><hr data-v-5dd1e269></div><div class="filter__period" data-v-5dd1e269><input type="number" placeholder="\u041E\u0442"${ssrRenderAttr("value", unref(filters).releasePeriodFrom)} data-v-5dd1e269><hr class="filter__period-divider" data-v-5dd1e269><input type="number" placeholder="\u0414\u043E"${ssrRenderAttr("value", unref(filters).releasePeriodTo)} data-v-5dd1e269></div></div>`);
      if (unref(isAnyFilterActive)) {
        _push(`<!--[--><hr class="filter__divider" data-v-5dd1e269>`);
        if (unref(isAnyFilterActive)) {
          _push(`<button class="filter__reset" data-v-5dd1e269> \u0421\u0431\u0440\u043E\u0441\u0438\u0442\u044C \u0444\u0438\u043B\u044C\u0442\u0440\u044B `);
          _push(ssrRenderComponent(_component_IconIcons, {
            cancle: "",
            size: 12,
            color: "var(--white-alpha50)"
          }, null, _parent));
          _push(`</button>`);
        } else {
          _push(`<!---->`);
        }
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Block/Filter.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-5dd1e269"]]);
const _sfc_main$3 = {
  __name: "Rating",
  __ssrInlineRender: true,
  props: {
    rate: {
      type: Number,
      default: 0
    }
  },
  setup(__props) {
    const rating = __props;
    return (_ctx, _push, _parent, _attrs) => {
      const _component_IconIcons = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["rating", {
          "rating-green": rating.rate <= 10 && rating.rate > 6,
          "rating-gray": rating.rate <= 6 && rating.rate > 4,
          "rating-red": rating.rate <= 4 && rating.rate >= 1,
          "rating-gray": !rating.rate
        }]
      }, _attrs))} data-v-667d5248>`);
      _push(ssrRenderComponent(_component_IconIcons, {
        rating: "",
        size: 12,
        color: "var(--white)"
      }, null, _parent));
      _push(`<h2 class="rating__rate" data-v-667d5248>${ssrInterpolate(rating.rate ? rating.rate : "\u041D\u0435\u0442")}</h2></div>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Rating.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-667d5248"]]);
const _imports_0 = "" + publicAssetsURL("card_poster.png");
const _sfc_main$2 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_UIRating = __nuxt_component_0;
  const _component_UIButton = __nuxt_component_1$1;
  const _component_IconIcons = __nuxt_component_2$1;
  const _component_NuxtLink = __nuxt_component_0$4;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "card" }, _attrs))} data-v-a884d3ee><div class="card__info" data-v-a884d3ee><div class="card__tools" data-v-a884d3ee>`);
  _push(ssrRenderComponent(_component_UIRating, { rate: 10 }, null, _parent));
  _push(ssrRenderComponent(_component_UIButton, { typeStyle: "['transparent', 'icon']" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_IconIcons, {
          favorite: "",
          size: 13,
          color: "var(--white)"
        }, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_IconIcons, {
            favorite: "",
            size: 13,
            color: "var(--white)"
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="card__img" data-v-a884d3ee>`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/watch" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="" data-v-a884d3ee${_scopeId}>`);
      } else {
        return [
          createVNode("img", {
            src: _imports_0,
            alt: ""
          })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div><h3 class="card__title" data-v-a884d3ee>\u0420\u0435\u0438\u043D\u043A\u0430\u0440\u043D\u0430\u0446\u0438\u044F \u0411\u0435\u0437\u0440\u0430\u0431\u043E\u0442\u043D\u043E\u0433\u043E</h3><div class="card__tags" data-v-a884d3ee><span data-v-a884d3ee>\u0412\u0435\u0441\u043D\u0430</span>`);
  _push(ssrRenderComponent(_component_IconIcons, {
    dot: "",
    size: 3,
    color: "var(--white-alpha50)"
  }, null, _parent));
  _push(`<span data-v-a884d3ee>2024</span>`);
  _push(ssrRenderComponent(_component_IconIcons, {
    dot: "",
    size: 3,
    color: "var(--white-alpha50)"
  }, null, _parent));
  _push(`<span data-v-a884d3ee>12 \u0441\u0435\u0440\u0438\u0439</span></div></div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/UI/Card.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender], ["__scopeId", "data-v-a884d3ee"]]);
const _sfc_main$1 = {
  __name: "Grid",
  __ssrInlineRender: true,
  setup(__props) {
    const { isMobile } = useDevice();
    const search = ref("");
    const view = ref("grid");
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockFilter = __nuxt_component_0$1;
      const _component_IconIcons = __nuxt_component_2$1;
      const _component_UICard = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid" }, _attrs))} data-v-27430369>`);
      if (!unref(isMobile)) {
        _push(`<div class="grid__filters" data-v-27430369>`);
        _push(ssrRenderComponent(_component_BlockFilter, null, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="grid__container" data-v-27430369><div class="grid__tools" data-v-27430369><div class="grid__search" data-v-27430369><input${ssrRenderAttr("value", unref(search))} type="text" placeholder="\u041F\u043E\u0438\u0441\u043A \u043F\u043E \u043A\u0430\u0442\u0430\u043B\u043E\u0433\u0443..." data-v-27430369>`);
      if (unref(search).trim().length > 0) {
        _push(`<span class="grid__search-reset" data-v-27430369>`);
        _push(ssrRenderComponent(_component_IconIcons, {
          cancle: "",
          size: 12,
          color: "var(--white-alpha50)"
        }, null, _parent));
        _push(`</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<button class="grid__search-button" data-v-27430369>`);
      _push(ssrRenderComponent(_component_IconIcons, {
        search: "",
        size: 16,
        color: "var(--white)"
      }, null, _parent));
      _push(`</button></div><div class="grid__view" data-v-27430369><div class="grid__view-buttons" data-v-27430369><button class="${ssrRenderClass([{ "grid__view-button--active": unref(view) === "columns" }, "grid__view-button"])}" data-v-27430369>`);
      _push(ssrRenderComponent(_component_IconIcons, {
        columns: "",
        size: 16,
        color: "var(--white-alpha50)"
      }, null, _parent));
      _push(`</button><button class="${ssrRenderClass([{ "grid__view-button--active": unref(view) === "grid" }, "grid__view-button"])}" data-v-27430369>`);
      _push(ssrRenderComponent(_component_IconIcons, {
        grid: "",
        size: 16,
        color: "var(--white-alpha50)"
      }, null, _parent));
      _push(`</button></div></div></div><div class="grid__wrapper" data-v-27430369><!--[-->`);
      ssrRenderList(10, (i) => {
        _push(ssrRenderComponent(_component_UICard, { key: i }, null, _parent));
      });
      _push(`<!--]--></div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Block/Grid.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-27430369"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useSeoMeta({
      twitterImage: "https://nekowrld.fun/chokola_nekopara.png",
      twitterCard: "summary_large_image",
      twitterDescription: "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0430\u043D\u0438\u043C\u0435-\u0445\u043E\u0441\u0442\u0438\u043D\u0433 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u0432\u0430\u0448\u0438\u0445 \u043B\u044E\u0431\u0438\u043C\u044B\u0445 \u0430\u043D\u0438\u043C\u0435!",
      lang: "ru",
      twitterTitle: "nekowrld.fun"
    });
    useHead({
      title: "\u0413\u043B\u0430\u0432\u043D\u0430\u044F \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430!",
      description: "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0430\u043D\u0438\u043C\u0435-\u0445\u043E\u0441\u0442\u0438\u043D\u0433 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u0432\u0430\u0448\u0438\u0445 \u043B\u044E\u0431\u0438\u043C\u044B\u0445 \u0430\u043D\u0438\u043C\u0435!",
      meta: [
        {
          hid: "description",
          name: "description",
          content: "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0430\u043D\u0438\u043C\u0435-\u0445\u043E\u0441\u0442\u0438\u043D\u0433 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u0432\u0430\u0448\u0438\u0445 \u043B\u044E\u0431\u0438\u043C\u044B\u0445 \u0430\u043D\u0438\u043C\u0435!"
        },
        { hid: "og:title", name: "og:title", content: "nekowrld" },
        {
          hid: "og:description",
          name: "og:description",
          content: "\u0411\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0430\u043D\u0438\u043C\u0435-\u0445\u043E\u0441\u0442\u0438\u043D\u0433 \u0434\u043B\u044F \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0430 \u0432\u0430\u0448\u0438\u0445 \u043B\u044E\u0431\u0438\u043C\u044B\u0445 \u0430\u043D\u0438\u043C\u0435!"
        },
        {
          hid: "og:image",
          name: "og:image",
          content: "https://nekowrld.fun/chokola_nekopara.png"
        },
        { hid: "og:url", name: "og:url", content: "https://nekoworld.fun" },
        { name: "theme-color", content: "#43B581" }
      ]
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlockBanner = __nuxt_component_0$3;
      const _component_BlockGrid = __nuxt_component_1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "container" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_BlockBanner, null, null, _parent));
      _push(ssrRenderComponent(_component_BlockGrid, null, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-4aacaa4f.mjs.map
