import { withAsyncContext, ref, resolveComponent, unref, useSSRContext } from 'vue';
import { f as defineStore, g as useRoute, u as useHead } from '../server.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrRenderStyle } from 'vue/server-renderer';
import axios from 'axios';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';

const anilibriaAPI = "https://api.anilibria.tv/v3";
const anilibria = defineStore({
  id: "anilibria",
  state: () => {
    return {
      titleList: [],
      title: [],
      titleUpdates: [],
      titleChanges: [],
      titleFranchise: [],
      titleSchedule: [],
      titleSearch: [],
      titleRandom: [],
      years: [],
      genres: [],
      feed: [],
      franchiseList: []
    };
  },
  actions: {
    async getTitle(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${anilibriaAPI}/title`,
          params
        });
        this.title = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getTitles(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${anilibriaAPI}/title/list`,
          params
        });
        this.titleList = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getTitleRandom() {
      try {
        const res = await axios({
          method: "GET",
          url: `${anilibriaAPI}/title/random`
        });
        this.titleRandom = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getFranchiseList(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${anilibriaAPI}/franchise/list`,
          params
        });
        this.franchiseList = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getFeed(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${anilibriaAPI}/feed`,
          params
        });
        this.feed = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async searchTitle(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${anilibriaAPI}/title/search`,
          params
        });
        this.titleSearch = res.data;
      } catch (err) {
        console.error(err);
      }
    }
  },
  getters: {
    infoTitle: (state) => state.title,
    infoTitles: (state) => state.titleList,
    infoRandom: (state) => state.titleRandom,
    infoFranchiseList: (state) => state.franchiseList,
    infoFeedList: (state) => state.feed,
    infoSearch: (state) => state.titleSearch
  }
});
const shikimoriAPI = "https://shikimori.me/api";
const shikimoriGrabber = "https://smarthard.net/api";
const shikimori = defineStore({
  id: "shikimori",
  state: () => {
    return {
      titleList: [],
      title: [],
      titleUpdates: [],
      titleChanges: [],
      titleFranchise: [],
      titleSchedule: [],
      titleSearch: [],
      titleRandom: [],
      years: [],
      genres: [],
      feed: [],
      franchiseList: [],
      titleVideo: []
    };
  },
  actions: {
    async getTitle(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${shikimoriAPI}/animes`,
          params
        });
        this.title = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getTitles() {
      try {
        const res = await axios({
          method: "GET",
          url: `${shikimoriAPI}/animes?limit=10`
        });
        this.titleList = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getTitleRandom() {
      try {
        const res = await axios({
          method: "GET",
          url: `${shikimoriAPI}/animes?order=random`
        });
        this.titleRandom = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async searchTitle(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${shikimoriAPI}/animes`,
          params
        });
        this.titleSearch = res.data;
      } catch (err) {
        console.error(err);
      }
    },
    async getVideoTitle(params) {
      try {
        const res = await axios({
          method: "POST",
          url: `${shikimoriGrabber}/shikivideos`,
          params
        });
        this.titleVideo = res.data;
      } catch (err) {
        console.error(err);
      }
    }
  },
  getters: {
    infoTitle: (state) => state.title,
    infoTitles: (state) => state.titleList,
    infoRandom: (state) => state.titleRandom,
    infoSearch: (state) => state.titleSearch,
    infoVideo: (state) => state.titleVideo
  }
});
const kodikAPI = "https://kodikapi.com";
const kodik = defineStore({
  id: "kodik",
  state: () => {
    return {
      titleList: [],
      translations: []
    };
  },
  actions: {
    async getTitle(params) {
      try {
        const res = await axios({
          method: "GET",
          url: `${kodikAPI}/search`,
          params
        });
        this.title = res.data;
      } catch (err) {
        console.error(err);
      }
    }
  },
  getters: {
    infoTitle: (state) => state.title
  }
});
const anilibriaCACHE = "https://cache.libria.fun";
const _sfc_main = {
  __name: "[code]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c;
    let __temp, __restore;
    const anilibriaStore = anilibria();
    const route = useRoute();
    [__temp, __restore] = withAsyncContext(() => anilibriaStore.getTitle({ code: route.params.code })), await __temp, __restore();
    const shikimoriStore = shikimori();
    [__temp, __restore] = withAsyncContext(() => {
      var _a2;
      return shikimoriStore.getTitle({
        search: (_a2 = anilibriaStore.infoTitle.names) == null ? void 0 : _a2.en
      });
    }), await __temp, __restore();
    const kodikStore = kodik();
    [__temp, __restore] = withAsyncContext(() => kodikStore.getTitle({
      token: "c73d5f30ac0f1720ef12225c0b683520",
      shikimori_id: shikimoriStore.infoTitle[0].id,
      translation_type: "voice"
    })), await __temp, __restore();
    useHead({
      title: `${(_a = anilibriaStore.infoTitle.names) == null ? void 0 : _a.ru}`,
      meta: [
        {
          hid: "og:title",
          name: "og:title",
          content: `${(_b = anilibriaStore.infoTitle.names) == null ? void 0 : _b.ru}`
        },
        {
          hid: "og:description",
          name: "og:description",
          content: `\u0421\u043C\u043E\u0442\u0440\u0435\u0442\u044C ${(_c = anilibriaStore.infoTitle.names) == null ? void 0 : _c.ru} \u043D\u0430 nekowrld. \u0421\u043E\u0432\u0435\u0440\u0448\u0435\u043D\u043E \u0431\u0435\u0441\u043F\u043B\u0430\u0442\u043D\u043E!`
        },
        {
          property: "og:image",
          name: "og:image",
          content: "assets/img/chokola_nekopara.png"
        },
        { property: "og:url", name: "og:url", content: "https://nekoworld.fun" },
        { name: "theme-color", content: "#43B581" },
        { twitterCard: "summary_large_image" }
      ]
    });
    ref(null);
    const lists = Object.values(anilibriaStore.infoTitle.player.list);
    let anilibriaLink = [];
    let kodikEpisodes = [];
    for (let i = 0; i < lists.length; i++) {
      const list = lists[i];
      anilibriaLink.push({
        title: `\u0421\u0435\u0440\u0438\u044F ${list.episode}`,
        id: list.episode,
        file: anilibriaCACHE + list.hls.fhd,
        poster: anilibriaCACHE + list.preview,
        timing: list.skips.opening
      });
      kodikEpisodes.push(list.episode);
    }
    console.log(kodikEpisodes);
    const selectedValues = ref([]);
    ref("");
    ref();
    const loadPlayer = () => {
      new Playerjs({
        id: "player",
        file: anilibriaLink,
        poster: anilibriaLink
        // title: anilibriaLink,
      });
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Script = resolveComponent("Script");
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_Script, {
        onLoad: loadPlayer,
        src: "/lib/player.js",
        type: "text/javascript"
      }, null, _parent));
      _push(`<div class="container"><div class="anime-page"><img class="anime-page__poster"${ssrRenderAttr("src", `${"https://shikimori.me" + unref(shikimoriStore).infoTitle[0].image.original}`)}><div class="anime-page__text"><div class="anime-page__text__title"> \u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435: ${ssrInterpolate(unref(anilibriaStore).infoTitle.names.ru)}</div><div class="anime-page__text__anoter-title"> \u0414\u0440\u0443\u0433\u043E\u0435 \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u0435: ${ssrInterpolate(unref(anilibriaStore).infoTitle.names.en)}</div><div class="anime-page__text__genres"> \u0416\u0430\u043D\u0440\u044B: <!--[-->`);
      ssrRenderList(unref(anilibriaStore).infoTitle.genres, (genre) => {
        _push(`<div>${ssrInterpolate(genre)}</div>`);
      });
      _push(`<!--]--></div></div></div><div class="anime-player"><div id="player"></div><iframe id="kodik-player" style="${ssrRenderStyle({ "width": "100%", "aspect-ratio": "16/9", "height": "100%" })}"${ssrRenderAttr("src", `//kodik.cc/find-player?shikimoriID=${unref(shikimoriStore).infoTitle[0].id}&camrip=false&types=anime,anime-serial&hide_selectors=false&episode=4`)} width="610px" height="370px" frameborder="0" allowfullscreen allow="autoplay *; fullscreen *"></iframe></div><!--[-->`);
      ssrRenderList(unref(kodikStore).infoTitle.results, (translation) => {
        _push(`<div><pre>${ssrInterpolate(translation.translation.id)}</pre></div>`);
      });
      _push(`<!--]--><div><select id="dropdown"><!--[-->`);
      ssrRenderList(unref(kodikEpisodes), (episode) => {
        _push(`<option>${ssrInterpolate(episode)}</option>`);
      });
      _push(`<!--]--></select><button>\u0414\u043E\u0431\u0430\u0432\u0438\u0442\u044C</button><ul><!--[-->`);
      ssrRenderList(unref(selectedValues), (value, index) => {
        _push(`<li>${ssrInterpolate(index + 1)}: ${ssrInterpolate(value)}</li>`);
      });
      _push(`<!--]--></ul></div></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/watch/[code].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_code_-7b62e448.mjs.map
