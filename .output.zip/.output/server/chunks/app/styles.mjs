const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.ce432207.mjs').then(interopDefault),
  "pages/auth.vue": () => import('./_nuxt/auth-styles.f2460d12.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.53bc572e.mjs').then(interopDefault),
  "pages/reg.vue": () => import('./_nuxt/reg-styles.e8286268.mjs').then(interopDefault),
  "pages/watch/index.vue": () => import('./_nuxt/index-styles.0001c145.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-404.vue": () => import('./_nuxt/error-404-styles.1e0dde27.mjs').then(interopDefault),
  "node_modules/@nuxt/ui-templates/dist/templates/error-500.vue": () => import('./_nuxt/error-500-styles.cf4b3e80.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.38c3ccfa.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
